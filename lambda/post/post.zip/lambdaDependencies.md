on VS code terminal:

npm i @aws-sdk/client-dynamodb @aws-sdk/lib-dynamodb