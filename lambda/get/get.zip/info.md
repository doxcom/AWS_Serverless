if zip command not work on VSCode terminal
run on powershell this as admin: choco install zip -y
restart vs code and it will work

